import { useEffect, useRef } from 'react';
import { Users, BarChart2, MessageSquare, Settings, FileText, Headphones, Target, PieChart } from 'lucide-react';
import { useIntersection } from '../hooks';

const skills = [
  { name: 'CRM & Pipeline Management', level: 92, icon: PieChart, desc: 'Lead funnel tracking, CRM tools, data-driven follow-ups' },
  { name: 'Team Leadership & Management', level: 90, icon: Users, desc: 'Building, coaching, and driving high-performance teams' },
  { name: 'Sales & Lead Conversion', level: 95, icon: Target, desc: 'Consultative selling, objection handling, closing strategies' },
  { name: 'Customer Relationship Management', level: 93, icon: MessageSquare, desc: 'Client retention, satisfaction management, trust building' },
  { name: 'Education Consulting', level: 88, icon: Headphones, desc: 'Study abroad guidance, university selection, admissions' },
  { name: 'Project & Campaign Management', level: 82, icon: Settings, desc: 'Marketing campaigns, cross-functional coordination' },
  { name: 'MS Office Suite', level: 85, icon: FileText, desc: 'Excel, Word, PowerPoint – reporting and documentation' },
  { name: 'Communication & Presentation', level: 91, icon: BarChart2, desc: 'Public speaking, stakeholder management, negotiation' },
];

function SkillBar({ skill, visible }: { skill: typeof skills[0]; visible: boolean }) {
  const barRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!visible) return;
    const el = barRef.current;
    if (!el) return;
    setTimeout(() => {
      el.style.width = `${skill.level}%`;
    }, 200);
  }, [visible, skill.level]);

  const Icon = skill.icon;

  return (
    <div className="glass-dark rounded-2xl p-5 border border-white/5 hover:border-gold-500/20 transition-all duration-300 hover:-translate-y-1 group">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-110"
          style={{ background: 'rgba(255,193,7,0.08)', border: '1px solid rgba(255,193,7,0.15)' }}>
          <Icon size={18} className="text-gold-500" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-0.5">
            <h4 className="text-sm font-semibold text-white leading-snug">{skill.name}</h4>
            <span className="text-xs font-bold text-gold-500 ml-2 flex-shrink-0">{skill.level}%</span>
          </div>
          <p className="text-xs text-white/40">{skill.desc}</p>
        </div>
      </div>
      <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
        <div
          ref={barRef}
          className="skill-bar-fill"
          style={{ width: '0%', transition: 'width 1.5s cubic-bezier(0.25, 0.46, 0.45, 0.94)' }}
        />
      </div>
    </div>
  );
}

const softSkills = [
  'Active Listening', 'Problem Solving', 'Emotional Intelligence', 'Adaptability',
  'Time Management', 'Conflict Resolution', 'Negotiation', 'Strategic Thinking',
  'Mentoring & Coaching', 'Cross-functional Collaboration',
];

export default function Skills() {
  const { ref, visible } = useIntersection(0.1);

  return (
    <section id="skills" className="relative py-24 bg-grid">
      <div className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse 60% 80% at 0% 50%, rgba(21,104,168,0.07) 0%, transparent 70%)' }} />
      <div className="max-w-7xl mx-auto px-6">
        <div ref={ref} className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center mb-16">
            <p className="section-subtitle">Core Competencies</p>
            <h2 className="section-title text-white">
              Professional <span className="gold-text">Skills</span>
            </h2>
            <div className="divider-gold mt-4" />
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-4 mb-12">
            {skills.map((skill) => (
              <SkillBar key={skill.name} skill={skill} visible={visible} />
            ))}
          </div>

          <div className="glass-dark rounded-2xl p-6 md:p-8 border border-white/5">
            <h3 className="text-sm uppercase tracking-widest text-gold-500 font-medium mb-5">Soft Skills & Personal Strengths</h3>
            <div className="flex flex-wrap gap-2.5">
              {softSkills.map((s) => (
                <span key={s} className="skill-chip">{s}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
