import { Mail, Phone, MapPin, Linkedin, Github, Instagram } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollTo = (id: string) => {
    document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative border-t border-white/5">
      <div className="absolute inset-0"
        style={{ background: 'linear-gradient(180deg, transparent, rgba(4,30,58,0.8))' }} />
      <div className="relative max-w-7xl mx-auto px-6 py-14">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #FFC107, #FFB300)' }}>
                <span className="text-navy-950 font-bold text-sm">HC</span>
              </div>
              <span className="font-display font-bold text-xl text-white">
                Habishek <span className="gold-text">Chandrakumar</span>
              </span>
            </div>
            <p className="text-white/45 text-sm leading-relaxed mb-5">
              Assistant Manager – Sales & Business Information Systems Undergraduate.
              Passionate about driving growth through people, strategy, and technology.
            </p>
            <div className="flex gap-3">
              {[
                { icon: Linkedin, href: 'https://www.linkedin.com/in/habishek-chandrakumar', label: 'LinkedIn' },
                { icon: Mail, href: 'mailto:habishek2K02@gmail.com', label: 'Email' },
                { icon: Phone, href: 'tel:+94779237787', label: 'Phone' },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  target={href.startsWith('http') ? '_blank' : undefined}
                  rel="noreferrer"
                  className="w-9 h-9 glass rounded-xl flex items-center justify-center border border-white/5 hover:border-gold-500/30 hover:text-gold-500 text-white/50 transition-all duration-300 hover:-translate-y-1"
                >
                  <Icon size={15} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="text-xs uppercase tracking-widest text-gold-500 font-medium mb-5">Quick Navigation</h4>
            <div className="grid grid-cols-2 gap-2">
              {[
                ['About', '#about'],
                ['Education', '#education'],
                ['Experience', '#experience'],
                ['Skills', '#skills'],
                ['Achievements', '#achievements'],
                ['Contact', '#contact'],
              ].map(([label, href]) => (
                <button
                  key={label}
                  onClick={() => scrollTo(href)}
                  className="text-left text-sm text-white/45 hover:text-gold-500 transition-colors py-1"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Contact details */}
          <div>
            <h4 className="text-xs uppercase tracking-widest text-gold-500 font-medium mb-5">Contact Details</h4>
            <div className="space-y-3">
              {[
                { icon: Mail, text: 'habishek2K02@gmail.com', href: 'mailto:habishek2K02@gmail.com' },
                { icon: Phone, text: '+94 779 237 787', href: 'tel:+94779237787' },
                { icon: MapPin, text: 'Kalubowila, Dehiwala, Sri Lanka', href: '#' },
              ].map(({ icon: Icon, text, href }) => (
                <a
                  key={text}
                  href={href}
                  className="flex items-start gap-2.5 text-sm text-white/45 hover:text-white/80 transition-colors"
                >
                  <Icon size={14} className="text-gold-500/60 flex-shrink-0 mt-0.5" />
                  {text}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/5 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/30">
            &copy; {currentYear} Habishek Chandrakumar. All rights reserved.
          </p>
          <p className="text-xs text-white/20">
            Assistant Manager – Sales | Business Information Systems Undergraduate
          </p>
        </div>
      </div>
    </footer>
  );
}
