import { TrendingUp, Users, Award, Star, Zap, BarChart } from 'lucide-react';
import { useIntersection, useCounter } from '../hooks';

const stats = [
  { value: 4, suffix: '+', label: 'Years of Experience', icon: Award },
  { value: 5, suffix: '', label: 'Roles & Promotions', icon: TrendingUp },
  { value: 3, suffix: '', label: 'Languages Spoken', icon: Star },
  { value: 90, suffix: '%+', label: 'Avg. Conversion Rate', icon: BarChart },
];

const achievements = [
  {
    icon: Award,
    title: 'Best Salesman - 2023',
    desc: 'Awarded "Best Salesman" for outstanding performance and exceptional sales results in 2023, recognized for excellence in customer engagement and revenue generation.',
    color: '#FFC107',
    featured: true,
    image: '/image.png',
  },
  {
    icon: TrendingUp,
    title: 'High Conversion Rates',
    desc: 'Consistently achieved above-average lead-to-enrolment conversion rates through consultative selling, trust-building, and structured follow-up processes.',
    color: '#FFC107',
  },
  {
    icon: Users,
    title: 'Team Management Success',
    desc: 'Successfully led and mentored multi-member telesales and counselling teams, ensuring KPI achievement and professional growth for team members.',
    color: '#1568A8',
  },
  {
    icon: Award,
    title: 'Student Enrolment Growth',
    desc: 'Played a key role in driving significant growth in student enrolment numbers across international study destinations through strategic campaigns.',
    color: '#0E5287',
  },
  {
    icon: Star,
    title: 'Customer Satisfaction',
    desc: 'Maintained high customer satisfaction scores by delivering transparent communication, resolving concerns promptly, and ensuring smooth onboarding.',
    color: '#FFB300',
  },
  {
    icon: Zap,
    title: 'Sales Performance Optimization',
    desc: 'Introduced performance improvement plans, CRM tracking, and daily reporting structures that measurably improved team productivity and target attainment.',
    color: '#1568A8',
  },
  {
    icon: BarChart,
    title: 'Career Progression',
    desc: 'Achieved rapid career growth from Junior Customer Care Executive to Assistant Manager – Sales within 4 years, a testament to consistent performance.',
    color: '#FFC107',
  },
];

function StatCard({ stat, visible }: { stat: typeof stats[0]; visible: boolean }) {
  const count = useCounter(stat.value, 2000, visible);
  const Icon = stat.icon;

  return (
    <div className="stat-card border border-white/5 hover:border-gold-500/20">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-4"
        style={{ background: 'rgba(255,193,7,0.08)', border: '1px solid rgba(255,193,7,0.2)' }}>
        <Icon size={22} className="text-gold-500" />
      </div>
      <p className="text-4xl font-bold gold-text mb-1">
        {count}{stat.suffix}
      </p>
      <p className="text-sm text-white/50">{stat.label}</p>
    </div>
  );
}

export default function Achievements() {
  const { ref, visible } = useIntersection(0.1);

  return (
    <section id="achievements" className="relative py-24">
      <div className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse 80% 50% at 50% 100%, rgba(255,193,7,0.04) 0%, transparent 70%)' }} />
      <div className="max-w-7xl mx-auto px-6">
        <div ref={ref} className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center mb-16">
            <p className="section-subtitle">Recognition & Impact</p>
            <h2 className="section-title text-white">
              Achievements & <span className="gold-text">Strengths</span>
            </h2>
            <div className="divider-gold mt-4" />
          </div>

          {/* Animated stat counters */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
            {stats.map((stat) => (
              <StatCard key={stat.label} stat={stat} visible={visible} />
            ))}
          </div>

          {/* Achievement cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {achievements.map(({ icon: Icon, title, desc, color, featured, image }, i) => (
              featured ? (
                <div
                  key={title}
                  className={`sm:col-span-2 lg:col-span-2 glass-dark rounded-2xl border border-gold-500/30 overflow-hidden transition-all duration-400 hover:-translate-y-2 group ${
                    visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                  }`}
                  style={{ transitionDelay: `${i * 80}ms`, boxShadow: '0 0 30px rgba(255,193,7,0.1)' }}
                >
                  <div className="grid md:grid-cols-2 gap-0">
                    {/* Image section */}
                    <div className="relative h-64 md:h-auto overflow-hidden bg-navy-950">
                      <img
                        src={image}
                        alt={title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-navy-950/60 via-transparent to-transparent" />
                    </div>
                    {/* Content section */}
                    <div className="p-8 flex flex-col justify-center">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 group-hover:scale-110"
                          style={{ background: `${color}20`, border: `2px solid ${color}` }}>
                          <Icon size={22} style={{ color }} />
                        </div>
                        <div>
                          <p className="text-xs uppercase tracking-widest text-gold-500 font-bold">Featured</p>
                          <h4 className="font-semibold text-lg text-white">{title}</h4>
                        </div>
                      </div>
                      <p className="text-sm text-white/70 leading-relaxed mb-6">{desc}</p>
                      <div className="h-1 rounded-full w-16"
                        style={{ background: color }} />
                    </div>
                  </div>
                </div>
              ) : (
                <div
                  key={title}
                  className={`glass-dark rounded-2xl p-6 border border-white/5 hover:border-white/10 transition-all duration-400 hover:-translate-y-2 group ${
                    visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                  }`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 group-hover:scale-110"
                      style={{ background: `${color}15`, border: `1px solid ${color}30` }}>
                      <Icon size={18} style={{ color }} />
                    </div>
                    <h4 className="font-semibold text-sm text-white">{title}</h4>
                  </div>
                  <p className="text-xs text-white/55 leading-relaxed">{desc}</p>
                  <div className="mt-4 h-0.5 rounded-full w-8 transition-all duration-300 group-hover:w-16"
                    style={{ background: color }} />
                </div>
              )
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
