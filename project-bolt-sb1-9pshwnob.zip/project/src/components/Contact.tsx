import { Mail, Phone, MapPin, Linkedin, MessageCircle, Send, ExternalLink } from 'lucide-react';
import { useState } from 'react';
import { useIntersection } from '../hooks';

const contactInfo = [
  {
    icon: Mail,
    label: 'Email Address',
    value: 'habishek2K02@gmail.com',
    href: 'mailto:habishek2K02@gmail.com',
    color: '#FFC107',
  },
  {
    icon: Phone,
    label: 'Phone Number',
    value: '+94 779 237 787',
    href: 'tel:+94779237787',
    color: '#1568A8',
  },
  {
    icon: MapPin,
    label: 'Location',
    value: 'No. 30/23A, De Silva Cross Road, Kalubowila, Dehiwala',
    href: '#',
    color: '#0E5287',
  },
  {
    icon: Linkedin,
    label: 'LinkedIn',
    value: 'linkedin.com/in/habishek-chandrakumar',
    href: 'https://www.linkedin.com/in/habishek-chandrakumar',
    color: '#1568A8',
  },
];

export default function Contact() {
  const { ref, visible } = useIntersection(0.15);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(form.subject || 'Portfolio Enquiry');
    const body = encodeURIComponent(`Hi Habishek,\n\nName: ${form.name}\nEmail: ${form.email}\n\n${form.message}`);
    window.open(`mailto:habishek2K02@gmail.com?subject=${subject}&body=${body}`);
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section id="contact" className="relative py-24">
      <div className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse 70% 60% at 50% 100%, rgba(21,104,168,0.08) 0%, transparent 70%)' }} />
      <div className="max-w-7xl mx-auto px-6">
        <div ref={ref} className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center mb-16">
            <p className="section-subtitle">Get In Touch</p>
            <h2 className="section-title text-white">
              Contact <span className="gold-text">Me</span>
            </h2>
            <div className="divider-gold mt-4" />
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <p className="text-white/60 leading-relaxed text-sm mb-8">
                I am open to new professional opportunities and collaborations. Whether you have a role in
                mind, want to discuss a project, or simply connect — I would love to hear from you.
              </p>

              <div className="space-y-4 mb-8">
                {contactInfo.map(({ icon: Icon, label, value, href, color }) => (
                  <a
                    key={label}
                    href={href}
                    target={href.startsWith('http') ? '_blank' : undefined}
                    rel="noreferrer"
                    className="flex items-start gap-4 glass-dark rounded-2xl p-4 border border-white/5 hover:border-gold-500/20 transition-all duration-300 hover:-translate-y-1 group"
                  >
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-110"
                      style={{ background: `${color}12`, border: `1px solid ${color}25` }}>
                      <Icon size={18} style={{ color }} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-white/40 uppercase tracking-wider mb-0.5">{label}</p>
                      <p className="text-sm text-white/80 group-hover:text-white transition-colors leading-snug break-all">{value}</p>
                    </div>
                    {href !== '#' && (
                      <ExternalLink size={13} className="text-white/20 group-hover:text-gold-500/60 transition-colors flex-shrink-0 mt-1 ml-auto" />
                    )}
                  </a>
                ))}
              </div>

              {/* WhatsApp CTA */}
              <a
                href="https://wa.me/94779237787?text=Hi%20Habishek%2C%20I%20came%20across%20your%20portfolio%20and%20would%20love%20to%20connect."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-3 w-full justify-center py-3.5 rounded-2xl font-semibold text-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
                style={{
                  background: 'linear-gradient(135deg, #25D366, #128C7E)',
                  color: '#fff',
                  boxShadow: '0 4px 20px rgba(37,211,102,0.2)',
                }}
              >
                <MessageCircle size={18} />
                Message on WhatsApp
              </a>
            </div>

            {/* Contact Form */}
            <div className="glass-dark rounded-3xl p-6 md:p-8 border border-white/5">
              <h3 className="text-lg font-semibold text-white mb-6">Send a Message</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-white/40 uppercase tracking-wider mb-1.5 block">Your Name</label>
                    <input
                      type="text"
                      required
                      placeholder="John Smith"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full glass rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/20 border border-white/5 focus:border-gold-500/40 focus:outline-none transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-white/40 uppercase tracking-wider mb-1.5 block">Email</label>
                    <input
                      type="email"
                      required
                      placeholder="you@email.com"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full glass rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/20 border border-white/5 focus:border-gold-500/40 focus:outline-none transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-white/40 uppercase tracking-wider mb-1.5 block">Subject</label>
                  <input
                    type="text"
                    placeholder="Job Opportunity / Collaboration"
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    className="w-full glass rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/20 border border-white/5 focus:border-gold-500/40 focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="text-xs text-white/40 uppercase tracking-wider mb-1.5 block">Message</label>
                  <textarea
                    required
                    rows={5}
                    placeholder="Write your message here..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full glass rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/20 border border-white/5 focus:border-gold-500/40 focus:outline-none transition-colors resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="btn-primary w-full justify-center"
                >
                  {sent ? (
                    <>Email Client Opened</>
                  ) : (
                    <>
                      <Send size={15} />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
