import { User, Target, Users, TrendingUp, BookOpen, Cpu } from 'lucide-react';
import { useIntersection } from '../hooks';

const traits = [
  { icon: Target, title: 'Sales Excellence', desc: 'Consistent high conversion rates with a consultative selling approach across international education markets.' },
  { icon: Users, title: 'Team Leadership', desc: 'Proven ability to build, mentor, and motivate cross-functional sales teams to exceed quarterly targets.' },
  { icon: TrendingUp, title: 'CRM Mastery', desc: 'Skilled in lead funnel management, pipeline tracking, and data-driven decision-making using CRM tools.' },
  { icon: BookOpen, title: 'Education Consulting', desc: 'Guided hundreds of students through course selection, university applications, and study abroad pathways.' },
  { icon: Cpu, title: 'Business & Technology', desc: 'Pursuing BSc in Business Information Systems, bridging the gap between digital solutions and business strategy.' },
  { icon: User, title: 'Customer Relations', desc: 'Committed to delivering exceptional customer experiences through transparent communication and empathy.' },
];

export default function About() {
  const { ref, visible } = useIntersection(0.15);

  return (
    <section id="about" className="relative py-24 section-glow-left">
      <div className="max-w-7xl mx-auto px-6">
        <div ref={ref} className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center mb-16">
            <p className="section-subtitle">Who I Am</p>
            <h2 className="section-title text-white">About <span className="gold-text">Me</span></h2>
            <div className="divider-gold mt-4 mb-6" />
            <p className="text-white/60 max-w-2xl mx-auto leading-relaxed">
              A mature, positive, and hardworking professional who consistently strives for the highest standard
              in every task. Capable of working under intense pressure with a passion for business and technology.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <div className="glass-dark rounded-3xl p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full opacity-10 blur-2xl"
                  style={{ background: 'radial-gradient(circle, #FFC107, transparent)' }} />
                <p className="text-section-subtitle text-gold-500 text-sm uppercase tracking-widest font-medium mb-4">
                  Profile Summary
                </p>
                <p className="text-white/75 leading-[1.85] text-sm md:text-base">
                  I am a results-driven sales and education consulting professional with over 4 years of progressive
                  experience at Primeleed Pvt Ltd and Bellvantage Pvt Ltd. Starting as a Junior Customer Care Executive
                  and rising to Assistant Manager – Sales, I have demonstrated exceptional leadership capabilities,
                  strategic thinking, and a deep commitment to client success.
                </p>
                <p className="text-white/75 leading-[1.85] text-sm md:text-base mt-4">
                  My expertise spans CRM & pipeline management, team training, lead conversion strategy, and
                  international education counselling. I thrive at the intersection of technology and business,
                  currently deepening my knowledge through a BSc in Business Information Systems at Cardiff
                  Metropolitan University.
                </p>
                <div className="mt-6 grid grid-cols-2 gap-4">
                  {[
                    { label: 'Name', value: 'Habishek Chandrakumar' },
                    { label: 'Role', value: 'Asst. Manager – Sales' },
                    { label: 'Location', value: 'Dehiwala, Sri Lanka' },
                    { label: 'Availability', value: 'Open to Offers' },
                  ].map(({ label, value }) => (
                    <div key={label}>
                      <p className="text-xs text-white/40 uppercase tracking-wider mb-0.5">{label}</p>
                      <p className="text-sm font-medium text-white/85">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {traits.map(({ icon: Icon, title, desc }, i) => (
                <div
                  key={title}
                  className={`glass rounded-2xl p-5 border border-white/5 hover:border-gold-500/20 transition-all duration-300 hover:-translate-y-1 group ${
                    visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                  }`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-all duration-300 group-hover:scale-110"
                    style={{ background: 'rgba(255,193,7,0.1)', border: '1px solid rgba(255,193,7,0.2)' }}>
                    <Icon size={18} className="text-gold-500" />
                  </div>
                  <h4 className="text-sm font-semibold text-white mb-1.5">{title}</h4>
                  <p className="text-xs text-white/50 leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
