import { Globe } from 'lucide-react';
import { useIntersection } from '../hooks';

const languages = [
  { name: 'English', level: 'Fluent', pct: 90, flag: '🇬🇧' },
  { name: 'Tamil', level: 'Native', pct: 100, flag: '🇱🇰' },
  { name: 'Sinhala', level: 'Proficient', pct: 78, flag: '🇱🇰' },
];

const references = [
  {
    name: 'Thasneema Farouk',
    title: 'Lecturer',
    company: 'ICBT Campus',
    credentials: 'MEd (AeU Malaysia) | BEd (Cambodia) | DEEMT (Col Uni)',
    email: 'thasneema.farouk@yahoo.com',
    phone: '077 918 6648',
    initials: 'TF',
    color: '#1568A8',
  },
  {
    name: 'Nayoni Fernando',
    title: 'Manager – Operations',
    company: 'Bellvantage Pvt Ltd',
    credentials: 'Senior Operations Management Professional',
    email: 'nayonif@bellvantage.com',
    phone: '077 676 2610',
    initials: 'NF',
    color: '#FFC107',
  },
];

export default function LanguagesAndReferences() {
  const { ref, visible } = useIntersection(0.15);

  return (
    <section id="languages" className="relative py-24 bg-grid">
      <div className="max-w-7xl mx-auto px-6">
        <div ref={ref} className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Languages */}
            <div>
              <div className="mb-10">
                <p className="section-subtitle text-left">Multilingual</p>
                <h2 className="section-title text-left text-white">
                  <span className="gold-text">Languages</span>
                </h2>
                <div className="divider-gold mt-4" style={{ margin: '1rem 0 0' }} />
              </div>

              <div className="space-y-5">
                {languages.map(({ name, level, pct, flag }, i) => (
                  <div
                    key={name}
                    className={`glass-dark rounded-2xl p-5 border border-white/5 hover:border-gold-500/15 transition-all duration-300 hover:-translate-y-1 ${
                      visible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-4'
                    }`}
                    style={{ transitionDelay: `${i * 100}ms` }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{flag}</span>
                        <div>
                          <p className="font-semibold text-white text-sm">{name}</p>
                          <p className="text-xs text-white/40">{level}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Globe size={14} className="text-gold-500/60" />
                        <span className="text-xs font-bold text-gold-500">{pct}%</span>
                      </div>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-1000"
                        style={{
                          width: visible ? `${pct}%` : '0%',
                          background: 'linear-gradient(90deg, #FFC107, #FFD54F)',
                          transitionDelay: `${i * 150 + 400}ms`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* References */}
            <div>
              <div className="mb-10">
                <p className="section-subtitle text-left">Professional References</p>
                <h2 className="section-title text-left text-white">
                  <span className="gold-text">References</span>
                </h2>
                <div className="divider-gold mt-4" style={{ margin: '1rem 0 0' }} />
              </div>

              <div className="space-y-5">
                {references.map(({ name, title, company, credentials, email, phone, initials, color }, i) => (
                  <div
                    key={name}
                    className={`glass-dark rounded-2xl p-6 border border-white/5 hover:border-gold-500/15 transition-all duration-300 hover:-translate-y-1 group ${
                      visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                    }`}
                    style={{ transitionDelay: `${i * 120}ms` }}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 font-bold text-xl text-white"
                        style={{ background: `${color}20`, border: `2px solid ${color}40` }}>
                        {initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-white text-sm">{name}</h4>
                        <p className="text-xs text-gold-500 font-medium">{title} · {company}</p>
                        <p className="text-xs text-white/40 mt-1 mb-3">{credentials}</p>
                        <div className="space-y-1.5">
                          <a href={`mailto:${email}`}
                            className="flex items-center gap-2 text-xs text-white/50 hover:text-gold-500 transition-colors">
                            <span className="w-1.5 h-1.5 rounded-full bg-gold-500/60" />
                            {email}
                          </a>
                          <a href={`tel:${phone}`}
                            className="flex items-center gap-2 text-xs text-white/50 hover:text-gold-500 transition-colors">
                            <span className="w-1.5 h-1.5 rounded-full bg-gold-500/60" />
                            {phone}
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
