import { GraduationCap, Award, Calendar } from 'lucide-react';
import { useIntersection } from '../hooks';

const education = [
  {
    degree: 'BSc in Business Information Systems',
    institution: 'Cardiff Metropolitan University',
    period: '05/2023 – Present',
    location: 'Colombo-04, Sri Lanka',
    type: 'Undergraduate Degree',
    highlight: true,
    details: ['Business strategy and digital systems', 'Data analytics and IT management', 'Bridging technology with business operations'],
  },
  {
    degree: 'HND in Software Engineering',
    institution: 'ICBT Campus',
    period: 'Completed',
    location: 'Sri Lanka',
    type: 'Higher National Diploma',
    highlight: false,
    details: ['Software development fundamentals', 'Systems analysis and design', 'Database management'],
  },
  {
    degree: 'G.C.E Advanced Level Examinations',
    institution: 'N/Cambridge College',
    period: '2021',
    location: 'Kotagala, Sri Lanka',
    type: 'Advanced Level',
    highlight: false,
    details: ['Economics – C', 'Business Studies – C', 'Accounting – S', 'General English – B'],
  },
  {
    degree: 'G.C.E Ordinary Level Examinations',
    institution: "N/Our Lady's School",
    period: '2018',
    location: 'Nuwara-Eliya, Sri Lanka',
    type: 'Ordinary Level',
    highlight: false,
    details: ['2 As (including English)', '7 Cs across core subjects'],
  },
];

export default function Education() {
  const { ref, visible } = useIntersection(0.15);

  return (
    <section id="education" className="relative py-24 bg-grid">
      <div className="absolute inset-0 opacity-30"
        style={{ background: 'radial-gradient(ellipse 70% 60% at 80% 50%, rgba(21,104,168,0.08) 0%, transparent 70%)' }} />
      <div className="max-w-7xl mx-auto px-6">
        <div ref={ref} className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center mb-16">
            <p className="section-subtitle">Academic Background</p>
            <h2 className="section-title text-white">
              <span className="gold-text">Education</span>
            </h2>
            <div className="divider-gold mt-4" />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {education.map((edu, i) => (
              <div
                key={edu.degree}
                className={`relative rounded-2xl p-6 md:p-8 transition-all duration-500 hover:-translate-y-2 group ${
                  edu.highlight
                    ? 'glass-gold border border-gold-500/20'
                    : 'glass-dark border border-white/5'
                } ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                {edu.highlight && (
                  <div className="absolute top-4 right-4">
                    <span className="text-xs font-semibold px-3 py-1 rounded-full"
                      style={{ background: 'rgba(255,193,7,0.15)', color: '#FFC107', border: '1px solid rgba(255,193,7,0.3)' }}>
                      Current
                    </span>
                  </div>
                )}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      background: edu.highlight ? 'rgba(255,193,7,0.15)' : 'rgba(255,255,255,0.05)',
                      border: edu.highlight ? '1px solid rgba(255,193,7,0.3)' : '1px solid rgba(255,255,255,0.08)',
                    }}>
                    {edu.highlight ? (
                      <GraduationCap size={22} className="text-gold-500" />
                    ) : (
                      <Award size={22} className="text-white/50" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs uppercase tracking-widest font-medium mb-1 ${edu.highlight ? 'text-gold-500' : 'text-white/40'}`}>
                      {edu.type}
                    </p>
                    <h3 className={`font-semibold text-base leading-snug mb-1 ${edu.highlight ? 'text-white' : 'text-white/85'}`}>
                      {edu.degree}
                    </h3>
                    <p className={`text-sm mb-3 ${edu.highlight ? 'text-white/70' : 'text-white/50'}`}>
                      {edu.institution}
                    </p>
                    <div className="flex items-center gap-1.5 text-xs text-white/40 mb-4">
                      <Calendar size={12} />
                      <span>{edu.period}</span>
                      <span className="mx-1">·</span>
                      <span>{edu.location}</span>
                    </div>
                    <ul className="space-y-1.5">
                      {edu.details.map((d) => (
                        <li key={d} className="flex items-start gap-2 text-xs text-white/55">
                          <span className="w-1.5 h-1.5 rounded-full bg-gold-500/60 flex-shrink-0 mt-1.5" />
                          {d}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
