import { Briefcase, MapPin, Calendar, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';
import { useIntersection } from '../hooks';

const experiences = [
  {
    title: 'Assistant Manager – Sales',
    company: 'Primeleed Pvt Ltd',
    period: 'Jul 2025 – Present',
    location: 'Wellawatte, Sri Lanka',
    color: '#FFC107',
    tag: 'Current',
    responsibilities: [
      'Managed and supervised telesales, counselling, and admission teams to achieve monthly and quarterly enrolment and revenue targets.',
      'Planned and executed sales strategies to increase lead conversion, student enrolments, and market share across key study destinations.',
      'Conducted sales training on product knowledge, counselling skills, objection handling, CRM usage, and customer relationship management.',
      'Analysed lead funnels and student profiles to optimize allocation of leads, streamline follow-ups, and shorten the admission conversion cycle.',
      'Communicated program information, entry criteria, tuition fees, visa requirements, and scholarship options to students and parents.',
      'Worked closely with marketing to evaluate lead sources and design campaigns that produced higher-quality leads and increased conversions.',
      'Developed partnerships with schools, training institutes, and corporate organizations to generate referral leads and strengthen market presence.',
    ],
    achievements: ['Led multi-team operations driving record quarterly enrolments', 'Reduced lead-to-enrolment cycle through CRM optimization'],
  },
  {
    title: 'Team Leader – Sales',
    company: 'Primeleed Pvt Ltd',
    period: 'Nov 2024 – Jul 2025',
    location: 'Wellawatte, Sri Lanka',
    color: '#1568A8',
    tag: null,
    responsibilities: [
      'Supervised and motivated a team of telesales executives and counsellors to achieve monthly and quarterly enrolment targets.',
      'Allocated leads strategically and enforced performance improvement plans to maintain productivity and target achievement.',
      'Represented the company at education fairs, school visits, webinars, and partnership meetings to support market expansion.',
      'Monitored individual and team performance, set daily call quotas, and implemented strategies to increase conversion rates.',
      'Conducted training sessions on product knowledge, objection handling, counselling techniques, CRM usage, and student engagement.',
      'Guided students through course selection, career pathways, university options, entry requirements, and scholarship opportunities.',
    ],
    achievements: ['Grew team enrolment conversions by consistent coaching', 'Represented company at major education expos'],
  },
  {
    title: 'Senior Tele-Sales Executive',
    company: 'Primeleed Pvt Ltd',
    period: 'Sep 2023 – Nov 2024',
    location: 'Wellawatte, Sri Lanka',
    color: '#0E5287',
    tag: null,
    responsibilities: [
      'Led telesales operations by managing outreach to prospective students and delivering accurate guidance on international and local education opportunities.',
      'Trained, mentored, and supported junior telesales staff to improve calling skills, objection handling, and enrolment conversions.',
      'Identified eligible students by assessing academic profiles, career interests, and admission requirements, recommending suitable universities and programs.',
      'Achieved high conversion rates by building trust, providing detailed program information, and professionally addressing financial, visa, and entry-related concerns.',
      'Monitored lead funnels through CRM, ensured timely follow-ups, and improved student onboarding efficiency from inquiry to enrolment.',
      'Coordinated closely with counsellors, admissions teams, and marketing departments to enhance lead quality and increase enrolment success.',
    ],
    achievements: ['Consistently met and exceeded monthly sales targets', 'Mentored junior staff improving team-wide performance'],
  },
  {
    title: 'Student Counsellor',
    company: 'Primeleed Pvt Ltd',
    period: 'Jan 2023 – Sep 2023',
    location: 'Wellawatte, Sri Lanka',
    color: '#062952',
    tag: null,
    responsibilities: [
      'Engaged with potential students via inbound/outbound calls to promote education programs and study abroad services.',
      'Assessed students\' academic background, interests, and eligibility to recommend suitable universities, courses, and countries.',
      'Generated and nurtured leads through cold calling, follow-ups, WhatsApp, and email campaigns.',
      'Explained program details, admission requirements, entry criteria, fees, and scholarship opportunities clearly and persuasively.',
      'Converted inquiries into enrolments by building trust, providing accurate guidance, and addressing objections professionally.',
      'Maintained student records in CRM systems and ensured timely follow-ups until enrolment confirmation.',
    ],
    achievements: ['High inquiry-to-enrolment conversion rate', 'Maintained detailed CRM records improving follow-up efficiency'],
  },
  {
    title: 'Junior Customer Care Executive',
    company: 'Bellvantage Pvt Ltd (Abans Process)',
    period: 'Mar 2022 – Sep 2022',
    location: 'Sri Lanka',
    color: '#041E3A',
    tag: null,
    responsibilities: [
      'Answered customer enquiries or passed them on to the appropriate department.',
      'Provided information and assistance to solve customer problems.',
      'Sold products and took orders from customers.',
      'Processed complaints and, where appropriate, issued refunds.',
      'Took information from customers and entered it into a database.',
      'Ensured every customer\'s experience was positive and professional.',
    ],
    achievements: ['Delivered consistent positive customer experience scores', 'Handled high-volume inbound calls with accuracy'],
  },
];

function ExperienceCard({ exp, index, visible }: { exp: typeof experiences[0]; index: number; visible: boolean }) {
  const [expanded, setExpanded] = useState(index === 0);

  return (
    <div
      className={`experience-card relative overflow-hidden transition-all duration-500 ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      {/* Color accent bar */}
      <div className="absolute left-0 top-0 bottom-0 w-1 rounded-l-2xl"
        style={{ background: exp.color }} />

      <div className="pl-4">
        <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h3 className="text-lg font-semibold text-white">{exp.title}</h3>
              {exp.tag && (
                <span className="text-xs px-2.5 py-0.5 rounded-full font-medium"
                  style={{ background: 'rgba(255,193,7,0.15)', color: '#FFC107', border: '1px solid rgba(255,193,7,0.3)' }}>
                  {exp.tag}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1.5 text-sm text-gold-500 font-medium">
              <Briefcase size={14} />
              {exp.company}
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-1.5 text-sm text-white/50 mb-1">
              <Calendar size={13} />
              {exp.period}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-white/35">
              <MapPin size={12} />
              {exp.location}
            </div>
          </div>
        </div>

        {/* Key achievements */}
        <div className="flex flex-wrap gap-2 mb-4">
          {exp.achievements.map((a) => (
            <span key={a} className="glass text-xs px-3 py-1 rounded-full text-white/60 border border-white/5">
              {a}
            </span>
          ))}
        </div>

        {/* Responsibilities toggle */}
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-1.5 text-xs text-white/40 hover:text-gold-500 transition-colors mb-3"
        >
          {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          {expanded ? 'Hide' : 'View'} Responsibilities
        </button>

        {expanded && (
          <ul className="space-y-2.5 mt-2">
            {exp.responsibilities.map((r, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-white/60 leading-relaxed">
                <span className="w-1.5 h-1.5 rounded-full flex-shrink-0 mt-2"
                  style={{ background: exp.color }} />
                {r}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default function Experience() {
  const { ref, visible } = useIntersection(0.1);

  return (
    <section id="experience" className="relative py-24">
      <div className="absolute inset-0 opacity-20"
        style={{ background: 'radial-gradient(ellipse 60% 80% at 100% 50%, rgba(255,193,7,0.05) 0%, transparent 70%)' }} />
      <div className="max-w-7xl mx-auto px-6">
        <div ref={ref} className={`transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center mb-16">
            <p className="section-subtitle">Career Journey</p>
            <h2 className="section-title text-white">
              Work <span className="gold-text">Experience</span>
            </h2>
            <div className="divider-gold mt-4" />
          </div>

          <div className="space-y-6">
            {experiences.map((exp, i) => (
              <ExperienceCard key={exp.title} exp={exp} index={i} visible={visible} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
