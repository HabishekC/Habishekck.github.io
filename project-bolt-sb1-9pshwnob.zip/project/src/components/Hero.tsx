import { Download, Mail, ChevronDown, MapPin, Phone } from 'lucide-react';
import { useIntersection } from '../hooks';

export default function Hero() {
  const { ref, visible } = useIntersection(0.1);

  const scrollDown = () => {
    document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-grid hero-glow"
    >
      {/* Background orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-10 blur-3xl pointer-events-none"
        style={{ background: 'radial-gradient(circle, #1568A8, transparent)' }} />
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 rounded-full opacity-8 blur-3xl pointer-events-none"
        style={{ background: 'radial-gradient(circle, #FFC107, transparent)' }} />

      <div
        ref={ref}
        className="max-w-7xl mx-auto px-6 pt-28 pb-16 w-full"
      >
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className={`transition-all duration-700 ${visible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}>
            <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-6">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-medium text-white/70 tracking-widest uppercase">
                Available for Opportunities
              </span>
            </div>

            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-4 text-shadow-gold">
              Habishek<br />
              <span className="gold-text">Chandrakumar</span>
            </h1>

            <p className="text-lg md:text-xl font-light text-white/60 mb-2 tracking-wide">
              Assistant Manager – Sales
            </p>
            <p className="text-sm text-white/40 mb-6 tracking-widest uppercase font-medium">
              Business Information Systems Undergraduate
            </p>

            <p className="text-white/70 leading-relaxed text-sm md:text-base max-w-md mb-8">
              A results-driven sales leader with expertise in education consulting, CRM,
              and team management. Proven track record of boosting enrolment conversion
              rates and building high-performing teams across international study destinations.
            </p>

            <div className="flex flex-wrap gap-4 mb-10">
              <a
                href="/cv-habishek-chandrakumar.pdf"
                className="btn-primary"
                download
              >
                <Download size={16} />
                Download CV
              </a>
              <a
                href="#contact"
                onClick={(e) => { e.preventDefault(); document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' }); }}
                className="btn-outline"
              >
                <Mail size={16} />
                Contact Me
              </a>
            </div>

            <div className="flex flex-wrap gap-6 text-sm text-white/50">
              <span className="flex items-center gap-1.5">
                <Mail size={14} className="text-gold-500" />
                habishek2K02@gmail.com
              </span>
              <span className="flex items-center gap-1.5">
                <Phone size={14} className="text-gold-500" />
                +94779237787
              </span>
              <span className="flex items-center gap-1.5">
                <MapPin size={14} className="text-gold-500" />
                Dehiwala, Sri Lanka
              </span>
            </div>
          </div>

          {/* Profile Image & Stats */}
          <div className={`transition-all duration-700 delay-200 ${visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
            <div className="relative flex flex-col items-center">
              {/* Professional profile container */}
              <div className="relative w-full max-w-sm mx-auto mb-12">
                {/* Background gradient orb */}
                <div className="absolute -inset-16 rounded-3xl opacity-25 blur-3xl pointer-events-none"
                  style={{ background: 'radial-gradient(circle, #FFC107, transparent)' }} />

                {/* Main profile card with glass effect */}
                <div className="relative rounded-3xl overflow-hidden glass-dark border border-gold-500/20 p-3 shadow-2xl"
                  style={{ boxShadow: '0 25px 60px rgba(255,193,7,0.2)' }}>

                  {/* Accent line top */}
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-gold-500 to-transparent z-10" />

                  {/* Image container - Full body shot */}
                  <div className="relative rounded-2xl overflow-hidden bg-navy-900 flex items-center justify-center"
                    style={{ aspectRatio: '3/4' }}>
                    <img
                      src="/MINE.jpeg"
                      alt="Habishek Chandrakumar"
                      className="w-full h-full object-cover object-top scale-100"
                    />
                    {/* Overlay gradient for depth */}
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-navy-950/20 pointer-events-none" />
                  </div>

                  {/* Professional info overlay at bottom */}
                  <div className="mt-4 px-5 pb-5 text-center">
                    <p className="text-xs uppercase tracking-widest text-gold-500 font-bold mb-1">Ready to Connect</p>
                    <p className="text-sm text-white/80 font-medium">Assistant Manager – Sales</p>
                  </div>
                </div>

                {/* Experience badge - positioned absolutely */}
                <div className="absolute -bottom-4 -right-2 glass-gold rounded-2xl px-4 py-2.5 shadow-lg border border-gold-500/40 z-20"
                  style={{ boxShadow: '0 12px 40px rgba(255,193,7,0.25)' }}>
                  <p className="text-sm font-bold text-gold-500">4+ Years</p>
                  <p className="text-xs text-white/70 font-medium">Experience</p>
                </div>
              </div>

              {/* Floating stat cards */}
              <div className="grid grid-cols-3 gap-3 w-full max-w-sm">
                {[
                  { value: '4+', label: 'Years Exp.' },
                  { value: '3', label: 'Languages' },
                  { value: '5', label: 'Roles Held' },
                ].map((stat) => (
                  <div key={stat.label} className="stat-card">
                    <p className="text-2xl font-bold gold-text">{stat.value}</p>
                    <p className="text-xs text-white/50 mt-0.5">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollDown}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30 hover:text-gold-500 transition-colors group"
      >
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <ChevronDown size={20} className="animate-bounce" />
      </button>
    </section>
  );
}
